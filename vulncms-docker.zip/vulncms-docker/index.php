<?php
$host = getenv("DB_HOST") ?: "localhost";  
$conn = new mysqli($host, "vulnuser", "vulnpass", "vulndb");


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $query = "SELECT * FROM users WHERE username='$username' AND password='$password'";
    $result = $conn->query($query);

    if ($result && $result->num_rows > 0) {
        echo "<div class='success'><h2>✅ Welcome Admin!</h2><a href='upload.php'>Go to File Upload</a></div>";
    } else {
        echo "<div class='error'>❌ Login failed.</div>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>VulnCMS Login</title>
    <style>
        body {
            background: #0f172a;
            color: #f1f5f9;
            font-family: Arial, sans-serif;
            text-align: center;
            padding-top: 100px;
        }
        .login-box {
            background: #1e293b;
            padding: 30px;
            border-radius: 10px;
            display: inline-block;
            box-shadow: 0 0 10px #0ea5e9;
        }
        input {
            padding: 10px;
            width: 80%;
            margin: 10px 0;
            border: none;
            border-radius: 5px;
        }
        button {
            padding: 10px 20px;
            background: #0ea5e9;
            border: none;
            border-radius: 5px;
            color: white;
            cursor: pointer;
        }
        .success, .error {
            margin-top: 20px;
            padding: 10px;
        }
        .success {
            color: #22c55e;
        }
        .error {
            color: #f87171;
        }
    </style>
</head>
<body>
    <div class="login-box">
        <h2>Login to VulnCMS</h2>
        <form method="post">
            <input type="text" name="username" placeholder="Username" required><br>
            <input type="password" name="password" placeholder="Password" required><br>
            <button type="submit">Login</button>
        </form>
    </div>
</body>
</html>
