<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

$uploadMessage = "";

if (isset($_FILES['file'])) {
    $file = $_FILES['file'];
    $filename = basename($file['name']);
    $tmp_path = $file['tmp_name'];
    $dest_path = "uploads/" . $filename;

    if (move_uploaded_file($tmp_path, $dest_path)) {
        $uploadMessage = "<div class='success'>✅ File uploaded: <a href='$dest_path'>$filename</a></div>";
    } else {
        $uploadMessage = "<div class='error'>❌ Upload failed.</div>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>File Upload - VulnCMS</title>
    <style>
        body {
            background: #0f172a;
            color: #f1f5f9;
            font-family: Arial, sans-serif;
            text-align: center;
            padding-top: 100px;
        }
        .upload-box {
            background: #1e293b;
            padding: 30px;
            border-radius: 10px;
            display: inline-block;
            box-shadow: 0 0 10px #10b981;
        }
        input[type="file"], input[type="submit"] {
            margin: 15px 0;
            padding: 10px;
            width: 80%;
            border-radius: 5px;
            border: none;
        }
        input[type="submit"] {
            background: #10b981;
            color: white;
            cursor: pointer;
        }
        .success, .error {
            margin-top: 20px;
            padding: 10px;
        }
        .success {
            color: #22c55e;
        }
        .error {
            color: #f87171;
        }
    </style>
</head>
<body>
    <div class="upload-box">
        <h2>Upload a File</h2>
        <?= $uploadMessage ?>
        <form method="POST" enctype="multipart/form-data">
            <input type="file" name="file" required><br>
            <input type="submit" value="Upload">
        </form>
    </div>
</body>
</html>
