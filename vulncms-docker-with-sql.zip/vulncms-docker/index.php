<?php
$host = getenv("DB_HOST") ?: "localhost";
$conn = new mysqli($host, "vulnuser", "vulnpass", "vulndb");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $query = "SELECT * FROM users WHERE username='$username' AND password='$password'";
    $result = $conn->query($query);

    if ($result && $result->num_rows > 0) {
        echo "<h2>✅ Welcome Admin!</h2><a href='upload.php'>Go to File Upload</a>";
    } else {
        echo "❌ Login failed.";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>VulnCMS Login</title>
</head>
<body>
    <h2>Login</h2>
    <form method="post">
        <input type="text" name="username" placeholder="Username"><br><br>
        <input type="password" name="password" placeholder="Password"><br><br>
        <button type="submit">Login</button>
    </form>
</body>
</html>
