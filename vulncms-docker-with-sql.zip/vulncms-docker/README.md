# VulnCMS – Dockerized Web Exploitation Lab

Practice SQL Injection, file upload vulnerabilities, and reverse shell execution in a Dockerized TryHackMe-style environment.

## 🚀 Usage

```bash
docker compose up --build
```

Visit [http://localhost:8080](http://localhost:8080)

## 🛠 Features

- SQL Injection login bypass
- Insecure file upload
- Reverse shell challenge
- Flag at `/uploads/flag.txt`

## 👨‍💻 Author

Asarutheen – NullClass Internship 2025
