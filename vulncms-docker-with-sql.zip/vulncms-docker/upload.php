<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

$uploadMessage = "";

if (isset($_FILES['file'])) {
    $file = $_FILES['file'];
    $filename = basename($file['name']);
    $tmp_path = $file['tmp_name'];
    $dest_path = "uploads/" . $filename;

    if (move_uploaded_file($tmp_path, $dest_path)) {
        $uploadMessage = "<div class='success'>✅ File uploaded: <a href='$dest_path'>$filename</a></div>";
    } else {
        $uploadMessage = "<div class='error'>❌ Upload failed.</div>";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Upload File</title>
</head>
<body>
    <h2>Upload a File</h2>
    <?= $uploadMessage ?>
    <form method="post" enctype="multipart/form-data">
        <input type="file" name="file"><br><br>
        <input type="submit" value="Upload">
    </form>
</body>
</html>
